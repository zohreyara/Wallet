package com.wallet.entity;

public enum Gender {
    MALE, FEMALE

}
