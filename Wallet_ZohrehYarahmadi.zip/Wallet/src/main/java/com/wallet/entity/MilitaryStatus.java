package com.wallet.entity;

public enum MilitaryStatus {
    COMPLETED, EXEMPT, DEFERRED;

    public boolean isEmpty() {

        return false;
    }
}
